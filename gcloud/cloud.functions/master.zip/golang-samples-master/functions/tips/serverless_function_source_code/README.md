This exists for use by the `ListFiles` sample.
