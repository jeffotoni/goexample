package main

import "mymath"

func main() {
	mymath.Sum(1, 2)
}
