package mymath

import "fmt"

func Sum(a, b int) {
	fmt.Println("sum: ", a+b)
}
